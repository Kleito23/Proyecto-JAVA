public class Main {
    public static void main(String[] args) {
        var valor = suma(20,30,50);
        System.out.println(valor);
        Coche miCoche = new Coche();
        miCoche.AumentarPuertas();
        System.out.println(miCoche.puertas);
    }
    public static int suma(int a,int b,int c) {
        return a + b + c;
    }

}

class Coche {
    public int puertas = 0;

    public void AumentarPuertas() {
        this.puertas++;
    }
}